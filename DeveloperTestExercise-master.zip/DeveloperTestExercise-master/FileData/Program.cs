﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {


        public static void Main(string[] args)
        {
            string version = string.Empty;
            string size = string.Empty;

            try
            {
                // Args 1 and Args 2 as Version and Size
                Console.WriteLine("args[0]" + args[0] + " " + args[1]);
                // Create object of FileDetails to call the Version and Size
                FileDetails fd = new FileDetails();
                version = Convert.ToString(fd.Version(@"C:\text.txt"));
                // Display the File Version
                Console.WriteLine("version : " + version);
                size = Convert.ToString(fd.Size(@"C:\text.txt"));
                // Display the File Size.
                Console.WriteLine("Size: " + size);
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}